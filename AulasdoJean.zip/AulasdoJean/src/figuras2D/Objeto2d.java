package figuras2D;

public interface Objeto2d {

    void moveX(float dX);
    void moveY(float dY);
    void move (float dX, float dY);
}
