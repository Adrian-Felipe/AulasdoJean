package figuras2D;

public interface Figura2d {
    float area();

    float perimetro();

    void moveX(float dX);

    void moveY(float dY);

    void move(float dX, float dY);
}
