package figuras2D;

public class Ponto2d implements Objeto2d {
    private float x, y;
    public Ponto2d(float x, float y) {
        this.x = x;
        this.y = y;
    }
    public float getX(){
        return x;
    }
    public float getY(){
        return y;
    }
    public void moveX(float dX) {
        x += dX;
    }
    public void moveY(float dY) {
        y += dY;
    }
    public void move(float dX, float dY) {
        x += dX;
        y += dY;
    }
    public String toString() {
        return "Ponto2d{" + "x = " + x + ", y = " + y + '}';
    }

    public void write() {
    }
}
