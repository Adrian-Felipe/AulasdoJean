package figurasgeo;

import figuras2D.Ponto2d;
import figuras2D.SegReta2D;
import figuras2D.Circulo;
import figuras2D.Quadrado;
import figuras2D.Retangulo;
import figuras2D.Triangulo;

public class FigGeografica {
    public static void main(String[] args) {
        Ponto2d p0 = new Ponto2d (2.9f , 4.2f);
        p0.write();
        Ponto2d p1 = new Ponto2d (4.4f , 5.7f);
        p1.write();
        Ponto2d p2 = new Ponto2d (4.4f , 5.7f);
        p2.write();
        SegReta2D sr0 = new SegReta2D(p0, p1);
        System.out.println(sr0.toString());
        Quadrado q1 = new Quadrado (p1, 2);
        q1.write();
        Retangulo r1 = new Retangulo (p1, 2, 4);
        r1.write();
        Circulo c0 = new Circulo(p1, 1.0f);
        c0.write();
        Triangulo t0 = new Triangulo(p0, p1, p2);
        t0.write();
    }
}
